using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EBid.lib.constant;

public partial class web_user_control_Purchasing_Purchasing_LeftNav : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {   
    }
    //protected void btnBidsForOpening_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("bidsForOpening.aspx");
    //}
    //protected void btnBidsForApproval_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("bids.aspx");
    //}
    //protected void btnBidsForReneg_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("BidsForRenegotiation.aspx");
    //}
    //protected void btnBidForConversion_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("bidsForConversion.aspx");
    //}
    //protected void btnRejectedBids_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("RejectedBidEvents.aspx");
    //}
    //protected void btnApprovedBidItems_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("ApprovedBidEvent.aspx");
    //}
    //protected void btnBidsForEvaluation_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("BidEventsforRe-Editing.aspx");
    //}
    //protected void btnUpdatedBids_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("BidsforEval.aspx");
    //}
    //protected void btnAwardedBidItems_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("awardedBidItems.aspx");
    //}
}
